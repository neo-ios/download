//
//  XGWechat.h
//  XGWechat
//
//  Created by apple on 06/12/2017.
//  Copyright © 2017 XGN. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for XGWechat.
FOUNDATION_EXPORT double XGWechatVersionNumber;

//! Project version string for XGWechat.
FOUNDATION_EXPORT const unsigned char XGWechatVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XGWechat/PublicHeader.h>


