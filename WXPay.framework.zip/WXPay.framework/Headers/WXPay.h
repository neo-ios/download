//
//  WXPay.h
//  WXPay
//
//  Created by JinglongBi on 2017/10/16.
//  Copyright © 2017年 jinglongbi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for WXPay.
FOUNDATION_EXPORT double WXPayVersionNumber;

//! Project version string for WXPay.
FOUNDATION_EXPORT const unsigned char WXPayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WXPay/PublicHeader.h>

#import "WechatAuthSDK.h"
#import "WXApi.h"
#import "WXApiObject.h"
